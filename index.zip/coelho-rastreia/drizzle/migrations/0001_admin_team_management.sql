CREATE OR REPLACE FUNCTION public.grant_designated_owner()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NEW.email_confirmed_at IS NOT NULL AND lower(NEW.email) = 'cledgang@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin') ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER grant_designated_owner_on_signup AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.grant_designated_owner();
CREATE TRIGGER grant_designated_owner_on_confirmation AFTER UPDATE OF email_confirmed_at, email ON auth.users FOR EACH ROW EXECUTE FUNCTION public.grant_designated_owner();
CREATE OR REPLACE FUNCTION public.handle_first_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NEW.email_confirmed_at IS NOT NULL THEN
    PERFORM pg_advisory_xact_lock(7241892);
    IF NOT EXISTS (SELECT 1 FROM public.user_roles) THEN
      INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin') ON CONFLICT (user_id, role) DO NOTHING;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER first_verified_user_role AFTER UPDATE OF email_confirmed_at ON auth.users FOR EACH ROW WHEN (OLD.email_confirmed_at IS NULL AND NEW.email_confirmed_at IS NOT NULL) EXECUTE FUNCTION public.handle_first_user();
CREATE OR REPLACE FUNCTION public.list_team_members()
RETURNS TABLE (user_id uuid, email text, created_at timestamptz, confirmed boolean, roles text[])
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Apenas administradores podem gerenciar a equipe' USING ERRCODE = '42501';
  END IF;
  RETURN QUERY SELECT u.id, u.email::text, u.created_at, u.email_confirmed_at IS NOT NULL,
    COALESCE(array_agg(r.role::text ORDER BY r.role::text) FILTER (WHERE r.role IS NOT NULL), ARRAY[]::text[])
  FROM auth.users u LEFT JOIN public.user_roles r ON r.user_id = u.id
  GROUP BY u.id, u.email, u.created_at, u.email_confirmed_at ORDER BY u.created_at DESC;
END;
$$;
REVOKE ALL ON FUNCTION public.list_team_members() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.list_team_members() TO authenticated;
CREATE OR REPLACE FUNCTION public.approve_team_member(_user_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Apenas administradores podem aprovar membros' USING ERRCODE = '42501';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE id = _user_id AND email_confirmed_at IS NOT NULL) THEN
    RAISE EXCEPTION 'O membro precisa confirmar o e-mail antes da aprovação' USING ERRCODE = '22023';
  END IF;
  IF NOT public.is_team(_user_id) THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (_user_id, 'staff') ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
END;
$$;
REVOKE ALL ON FUNCTION public.approve_team_member(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.approve_team_member(uuid) TO authenticated;