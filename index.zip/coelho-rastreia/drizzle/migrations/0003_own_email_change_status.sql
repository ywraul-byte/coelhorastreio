CREATE OR REPLACE FUNCTION public.my_email_change_status()
RETURNS TABLE (current_email text, pending_email text, confirmation_count integer, sent_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Entre para consultar a troca de e-mail' USING ERRCODE = '42501';
  END IF;
  RETURN QUERY SELECT u.email::text, NULLIF(u.email_change, '')::text, COALESCE(u.email_change_confirm_status, 0)::integer, u.email_change_sent_at
  FROM auth.users u WHERE u.id = auth.uid();
END;
$$;
REVOKE ALL ON FUNCTION public.my_email_change_status() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.my_email_change_status() TO authenticated;