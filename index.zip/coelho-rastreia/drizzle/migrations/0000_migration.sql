create type public.app_role as enum ('admin', 'staff');
create type public.shipment_step as enum ('separado','postado','transito','centro','saiu','entregue');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create or replace function public.is_team(_user_id uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id) $$;

create policy "own roles readable" on public.user_roles for select to authenticated using (user_id = auth.uid());

-- First account ever created becomes the owner (admin)
create or replace function public.handle_first_user()
returns trigger language plpgsql security definer set search_path = public
as $$ begin
  if not exists (select 1 from public.user_roles) then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  end if;
  return new;
end $$;
create trigger on_auth_user_created_role after insert on auth.users
for each row execute function public.handle_first_user();

create table public.shipments (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  recipient text not null,
  origin text not null default '',
  destination text not null,
  carrier text not null,
  status shipment_step not null default 'separado',
  eta date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.shipments to authenticated;
grant all on public.shipments to service_role;
alter table public.shipments enable row level security;
create policy "team manages shipments" on public.shipments for all to authenticated
  using (public.is_team(auth.uid())) with check (public.is_team(auth.uid()));

create table public.shipment_events (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  step shipment_step not null,
  title text not null,
  detail text not null default '',
  location text not null default '',
  occurred_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index on public.shipment_events (shipment_id, occurred_at desc);
grant select, insert, update, delete on public.shipment_events to authenticated;
grant all on public.shipment_events to service_role;
alter table public.shipment_events enable row level security;
create policy "team manages events" on public.shipment_events for all to authenticated
  using (public.is_team(auth.uid())) with check (public.is_team(auth.uid()));

-- Public lookup by exact code; never exposes recipient name
create or replace function public.track_shipment(_code text)
returns json language sql stable security definer set search_path = public
as $$
  select json_build_object(
    'code', s.code, 'carrier', s.carrier, 'origin', s.origin, 'destination', s.destination,
    'status', s.status, 'eta', s.eta,
    'events', coalesce((select json_agg(json_build_object('step', e.step, 'title', e.title, 'detail', e.detail, 'location', e.location, 'date', e.occurred_at) order by e.occurred_at desc)
      from public.shipment_events e where e.shipment_id = s.id), '[]'::json))
  from public.shipments s where s.code = upper(trim(_code))
$$;
revoke all on function public.track_shipment(text) from public;
grant execute on function public.track_shipment(text) to anon, authenticated;

alter publication supabase_realtime add table public.shipment_events;
alter publication supabase_realtime add table public.shipments;