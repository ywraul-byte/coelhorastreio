ALTER TABLE public.shipments ADD COLUMN product text NOT NULL DEFAULT '';
CREATE OR REPLACE FUNCTION public.create_team_order(_recipient text, _product text, _eta date, _step public.shipment_step, _origin text, _destination text, _carrier text)
RETURNS TABLE (id uuid, code text)
LANGUAGE plpgsql SECURITY INVOKER SET search_path = public
AS $$
DECLARE
  order_id uuid := gen_random_uuid();
  order_code text := 'CR' || upper(replace(gen_random_uuid()::text, '-', ''));
  event_title text;
BEGIN
  IF auth.uid() IS NULL OR NOT public.is_team(auth.uid()) THEN
    RAISE EXCEPTION 'Acesso restrito à equipe' USING ERRCODE = '42501';
  END IF;
  IF nullif(trim(_recipient), '') IS NULL OR nullif(trim(_product), '') IS NULL OR nullif(trim(_destination), '') IS NULL OR nullif(trim(_carrier), '') IS NULL OR _step IS NULL THEN
    RAISE EXCEPTION 'Preencha cliente, produto, destino, transportadora e etapa' USING ERRCODE = '22023';
  END IF;
  IF length(trim(_recipient)) > 120 OR length(trim(_product)) > 240 OR length(trim(_destination)) > 80 OR length(trim(_origin)) > 80 OR length(trim(_carrier)) > 80 THEN
    RAISE EXCEPTION 'Um dos campos ultrapassa o tamanho permitido' USING ERRCODE = '22023';
  END IF;
  event_title := CASE _step
    WHEN 'separado' THEN 'Seu pedido está sendo preparado para envio'
    WHEN 'postado' THEN 'Objeto postado'
    WHEN 'transito' THEN 'Em trânsito'
    WHEN 'centro' THEN 'No centro de distribuição'
    WHEN 'saiu' THEN 'Saiu para entrega'
    WHEN 'entregue' THEN 'Entregue ao destinatário' END;
  INSERT INTO public.shipments (id, code, recipient, product, eta, status, origin, destination, carrier)
  VALUES (order_id, order_code, trim(_recipient), trim(_product), _eta, _step, coalesce(trim(_origin), ''), trim(_destination), trim(_carrier));
  INSERT INTO public.shipment_events (shipment_id, step, title, location)
  VALUES (order_id, _step, event_title, coalesce(nullif(trim(_origin), ''), trim(_destination)));
  RETURN QUERY SELECT order_id, order_code;
END;
$$;
REVOKE ALL ON FUNCTION public.create_team_order(text,text,date,public.shipment_step,text,text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_team_order(text,text,date,public.shipment_step,text,text,text) TO authenticated;