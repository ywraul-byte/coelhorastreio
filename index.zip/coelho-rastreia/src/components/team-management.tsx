import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Check, RefreshCw, ShieldCheck, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { canApproveMember } from "@/lib/team-permissions";

export function TeamManagement({ ownerId }: { ownerId: string }) {
  const qc = useQueryClient();
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const members = useQuery({
    queryKey: ["team-members", ownerId],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("list_team_members");
      if (error) throw error;
      return data;
    },
  });

  const approve = async (id: string) => {
    setBusy(id); setMessage("");
    try {
      const { error } = await supabase.rpc("approve_team_member", { _user_id: id });
      if (error) throw error;
      await qc.invalidateQueries({ queryKey: ["team-members", ownerId] });
      setMessage("Membro aprovado. O acesso ao painel está liberado.");
    } catch {
      setMessage("Não foi possível aprovar. Confira se o e-mail foi confirmado e tente novamente.");
    } finally {
      setBusy(null);
    }
  };

  return (
    <section aria-labelledby="team-heading" className="border-t pt-8">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 id="team-heading" className="flex items-center gap-2 font-display text-xl font-extrabold"><Users className="size-5 text-primary" /> Gestão de equipe</h2>
        <Button variant="outline" size="icon" aria-label="Atualizar equipe" title="Atualizar equipe" disabled={members.isFetching} onClick={() => void members.refetch()}><RefreshCw /></Button>
      </div>
      {message && <p role="status" className="mb-4 text-sm font-semibold">{message}</p>}
      {members.isPending ? <p className="text-sm text-muted-foreground">Carregando equipe…</p>
        : members.isError ? <p role="alert" className="text-sm text-destructive">Não foi possível carregar a equipe. Tente atualizar.</p>
        : <ul className="divide-y border-y">
          {members.data.map((member) => {
            const admin = member.roles.includes("admin");
            const active = member.roles.length > 0;
            return <li key={member.user_id} className="flex flex-wrap items-center justify-between gap-3 py-4">
              <div className="min-w-0 flex-1">
                <p className="break-all font-semibold">{member.email}{member.user_id === ownerId ? " (você)" : ""}</p>
                <p className="mt-1 text-xs text-muted-foreground">Cadastro: {new Date(member.created_at).toLocaleDateString("pt-BR")} · {member.confirmed ? "E-mail confirmado" : "Aguardando confirmação do e-mail"}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-xs font-bold text-muted-foreground">{admin && <ShieldCheck className="size-4 text-primary" />}{admin ? "Administrador" : active ? "Equipe aprovada" : "Pendente"}</span>
                {canApproveMember(member.confirmed, member.roles) && <Button size="sm" disabled={busy !== null} onClick={() => void approve(member.user_id)}><Check />{busy === member.user_id ? "Aprovando…" : "Aprovar"}</Button>}
              </div>
            </li>;
          })}
          {members.data.length === 0 && <li className="py-4 text-sm text-muted-foreground">Nenhum membro cadastrado.</li>}
        </ul>}
    </section>
  );
}