import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { CheckCircle2, Clock, Mail, RefreshCw, Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { emailChangeState } from "@/lib/email-change";

export function EmailChangeStatus({ userId }: { userId: string }) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [failed, setFailed] = useState(false);
  const status = useQuery({
    queryKey: ["email-change", userId],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("my_email_change_status");
      if (error) throw error;
      return data[0] ?? null;
    },
    refetchInterval: 15000,
  });
  const info = status.data;
  const state = info ? emailChangeState(info.pending_email, info.confirmation_count) : null;

  const resend = async () => {
    if (!info?.pending_email) return;
    setBusy(true); setMessage(""); setFailed(false);
    try {
      const { error } = await supabase.auth.resend({
        type: "email_change",
        email: info.current_email,
        options: { emailRedirectTo: `${window.location.origin}/auth` },
      });
      if (error) {
        setFailed(true);
        setMessage(error.status === 429 ? "Muitas solicitações. Aguarde alguns minutos antes de reenviar." : "Não foi possível reenviar os links. Tente novamente.");
        return;
      }
      setMessage("Novos links solicitados para os dois endereços. Confira as caixas de entrada e o spam; use os links mais recentes.");
      await status.refetch();
    } catch {
      setFailed(true); setMessage("Não foi possível reenviar os links. Tente novamente.");
    } finally {
      setBusy(false);
    }
  };

  return <section aria-labelledby="email-change-heading" className="border-y py-5">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <h2 id="email-change-heading" className="flex items-center gap-2 font-display text-lg font-extrabold"><Mail className="size-5 text-primary" /> Troca de e-mail</h2>
      <Button variant="ghost" size="icon" aria-label="Atualizar confirmação de e-mail" title="Atualizar confirmação de e-mail" disabled={status.isFetching} onClick={() => void status.refetch()}><RefreshCw /></Button>
    </div>
    {status.isPending ? <p className="mt-3 text-sm text-muted-foreground">Consultando confirmação…</p>
      : status.isError || !info ? <p role="alert" className="mt-3 text-sm text-destructive">Não foi possível consultar a troca de e-mail.</p>
      : <div className="mt-3 space-y-3">
        <p role="status" className="flex items-center gap-2 text-sm font-semibold">{state === "complete" ? <CheckCircle2 className="size-4 text-success" /> : <Clock className="size-4 text-primary" />}{state === "complete" ? "Nenhuma troca pendente" : state === "partial" ? "Confirmação parcial · falta confirmar um dos endereços" : "Aguardando confirmação dos e-mails"}</p>
        <div className="grid gap-3 text-sm sm:grid-cols-2">
          <div><p className="text-xs font-bold uppercase text-muted-foreground">E-mail atual</p><p className="mt-1 break-all font-mono">{info.current_email}</p></div>
          {info.pending_email && <div><p className="text-xs font-bold uppercase text-muted-foreground">Novo e-mail · pendente</p><p className="mt-1 break-all font-mono">{info.pending_email}</p></div>}
        </div>
        {info.pending_email && <div className="flex flex-wrap items-center gap-3">
          <Button variant="outline" onClick={() => void resend()} disabled={busy || status.isFetching}><Send />{busy ? "Reenviando…" : "Reenviar para os dois e-mails"}</Button>
          {info.sent_at && <p className="text-xs text-muted-foreground">Última solicitação: {new Date(info.sent_at).toLocaleString("pt-BR")}</p>}
        </div>}
        {message && <p role={failed ? "alert" : "status"} className={`text-sm ${failed ? "text-destructive" : "text-muted-foreground"}`}>{message}</p>}
      </div>}
  </section>;
}