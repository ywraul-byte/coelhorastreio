export function canManageTeam(roles: readonly string[]) {
  return roles.includes("admin");
}

export function canApproveMember(confirmed: boolean, roles: readonly string[]) {
  return confirmed && roles.length === 0;
}