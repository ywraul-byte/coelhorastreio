import { expect, test } from "vitest";
import { canApproveMember, canManageTeam } from "./team-permissions";

test("only admin can manage the team, not staff or pending users", () => {
  expect(canManageTeam(["admin"])).toBe(true);
  expect(canManageTeam(["staff"])).toBe(false);
  expect(canManageTeam([])).toBe(false);
});

test("only confirmed members without a role can be approved", () => {
  expect(canApproveMember(true, [])).toBe(true);
  expect(canApproveMember(false, [])).toBe(false);
  expect(canApproveMember(true, ["staff"])).toBe(false);
  expect(canApproveMember(true, ["admin"])).toBe(false);
});