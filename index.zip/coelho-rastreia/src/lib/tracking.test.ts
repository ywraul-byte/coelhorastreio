import { expect, test } from "vitest";
import { buildShipment, STATUS_SAMPLES } from "./tracking";
test.each(STATUS_SAMPLES)("sample $code shows status $status", ({ code, status }) => {
  expect(buildShipment(code)?.status).toBe(status);
});

test("separated order shows preparing message", () => {
  const code = STATUS_SAMPLES.find((s) => s.status === "separado")!.code;
  expect(buildShipment(code)!.events[0]!.title).toBe("Seu pedido está sendo preparado para envio");
});
