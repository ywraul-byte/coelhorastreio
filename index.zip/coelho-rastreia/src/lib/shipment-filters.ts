import type { StepKey } from "./tracking";

export type ShipmentStatusFilter = "all" | StepKey;

export function filterShipments<T extends { code: string; status: StepKey }>(
  shipments: T[],
  codeSearch: string,
  status: ShipmentStatusFilter,
): T[] {
  const search = codeSearch.trim().toUpperCase();
  return shipments.filter((shipment) =>
    shipment.code.toUpperCase().includes(search) &&
    (status === "all" || shipment.status === status),
  );
}