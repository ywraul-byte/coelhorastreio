export function emailChangeState(pendingEmail: string | null, confirmations: number) {
  if (!pendingEmail) return "complete";
  return confirmations === 1 ? "partial" : "pending";
}