import { expect, test } from "vitest";
import { filterShipments } from "./shipment-filters";
import { STEP_ORDER } from "./tracking";

const shipments = STEP_ORDER.map((status, index) => ({ code: `QB00000${index}BR`, status }));

test("code search matches a partial code regardless of case or surrounding spaces", () => {
  expect(filterShipments(shipments, "  qb000003  ", "all")).toEqual([shipments[3]]);
});

test.each(STEP_ORDER)("status filter only returns %s shipments", (status) => {
  expect(filterShipments(shipments, "", status)).toEqual(shipments.filter((s) => s.status === status));
});

test("code search and status filter are combined", () => {
  expect(filterShipments(shipments, "000003", "entregue")).toEqual([]);
  expect(filterShipments(shipments, "000003", "centro")).toEqual([shipments[3]]);
});

test("cleared filters restore all shipments without changing their order", () => {
  expect(filterShipments(shipments, "", "all")).toEqual(shipments);
});