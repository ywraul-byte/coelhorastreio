export type StepKey = "separado" | "postado" | "transito" | "centro" | "saiu" | "entregue";
export type Carrier = "Correios" | "Jadlog" | "Loggi" | "Total Express" | "Azul Cargo";

export interface TrackEvent {
  step: StepKey;
  title: string;
  detail: string;
  location: string;
  date: string; // ISO
}

export interface Shipment {
  code: string;
  carrier: string;
  origin: string;
  destination: string;
  eta: string;
  status: StepKey;
  events: TrackEvent[]; // newest first
}

export const STEP_LABEL: Record<StepKey, string> = {
  separado: "Em preparação",
  postado: "Postado",
  transito: "Em trânsito",
  centro: "Centro de distribuição",
  saiu: "Saiu para entrega",
  entregue: "Entregue",
};
export const STEP_ORDER: StepKey[] = ["separado", "postado", "transito", "centro", "saiu", "entregue"];

export const CARRIERS: { name: Carrier; pattern: string; desc: string; regex: RegExp }[] = [
  { name: "Correios", pattern: "AA123456789BR", desc: "SEDEX, PAC e internacionais", regex: /^[A-Z]{2}\d{9}[A-Z]{2}$/ },
  { name: "Jadlog", pattern: "14 dígitos", desc: ".Package, .Com e Rodoviário", regex: /^\d{14}$/ },
  { name: "Loggi", pattern: "LGI + 10 caracteres", desc: "Entregas expressas urbanas", regex: /^LGI[A-Z0-9]{10}$/ },
  { name: "Total Express", pattern: "TE + 10 dígitos", desc: "E-commerce em todo o Brasil", regex: /^TE\d{10}$/ },
  { name: "Azul Cargo", pattern: "AZ + 9 dígitos", desc: "Aéreo expresso nacional", regex: /^AZ\d{9}$/ },
];

export function detectCarrier(code: string): Carrier | null {
  const c = code.trim().toUpperCase();
  return CARRIERS.find((x) => x.regex.test(c))?.name ?? null;
}

const CITIES = ["São Paulo, SP", "Curitiba, PR", "Belo Horizonte, MG", "Rio de Janeiro, RJ", "Porto Alegre, RS", "Recife, PE", "Salvador, BA", "Goiânia, GO", "Campinas, SP", "Fortaleza, CE"];

function hash(s: string) {
  let h = 2166136261;
  for (const ch of s) h = Math.imul(h ^ ch.charCodeAt(0), 16777619);
  return Math.abs(h);
}

/** Demo generator: deterministic simulated tracking for any valid code. */
export function buildShipment(rawCode: string, now = new Date()): Shipment | null {
  const code = rawCode.trim().toUpperCase();
  const carrier = detectCarrier(code);
  if (!carrier) return null;
  const h = hash(code);
  const origin = CITIES[h % CITIES.length]!;
  let destination = CITIES[(h >> 4) % CITIES.length]!;
  if (destination === origin) destination = CITIES[(h % CITIES.length + 3) % CITIES.length]!;
  const progress = (h >> 8) % 6; // index of current step
  const status = STEP_ORDER[progress]!;
  const hours = [0, 6, 20, 36, 52, 58];
  const start = new Date(now.getTime() - (hours[progress]! + 2) * 3600e3);
  const at = (i: number) => new Date(start.getTime() + hours[i]! * 3600e3 + ((h >> i) % 50) * 60e3).toISOString();
  const hub = destination.replace(/,.*/, "");
  const all: TrackEvent[] = [
    { step: "separado", title: "Seu pedido está sendo preparado para envio", detail: "Pedido separado pela loja, aguardando coleta da transportadora", location: origin, date: at(0) },
    { step: "postado", title: "Objeto postado", detail: `Recebido pela ${carrier} na agência de origem`, location: origin, date: at(1) },
    { step: "transito", title: "Em trânsito", detail: `Encaminhado de ${origin.replace(/,.*/, "")} para ${hub}`, location: origin, date: at(2) },
    { step: "centro", title: "No centro de distribuição", detail: "Triagem concluída, aguardando rota", location: `CD ${hub}`, date: at(3) },
    { step: "saiu", title: "Saiu para entrega", detail: "O entregador está a caminho do endereço", location: destination, date: at(4) },
    { step: "entregue", title: "Entregue ao destinatário", detail: "Entrega confirmada com assinatura", location: destination, date: at(5) },
  ];
  const eta = new Date(start.getTime() + 62 * 3600e3).toISOString();
  return { code, carrier, origin, destination, eta, status, events: all.slice(0, progress + 1).reverse() };
}

/** Look up a real shipment registered in the owner panel; falls back to demo codes. */
export async function fetchShipment(rawCode: string): Promise<{ shipment: Shipment; live: boolean } | null> {
  const code = rawCode.trim().toUpperCase();
  if (!code) return null;
  const { supabase } = await import("@/integrations/supabase/client");
  const { data } = await supabase.rpc("track_shipment", { _code: code });
  if (data) {
    const d = data as unknown as Shipment & { eta: string | null };
    return { shipment: { ...d, eta: d.eta ? `${d.eta}T12:00:00` : "" }, live: true };
  }
  const demo = buildShipment(code);
  return demo ? { shipment: demo, live: false } : null;
}

export const SAMPLE_CODES: { carrier: Carrier; code: string }[] = [
  { carrier: "Correios", code: "QB482915736BR" },
  { carrier: "Jadlog", code: "10084529317746" },
  { carrier: "Loggi", code: "LGI7K2M9QX4PT" },
  { carrier: "Total Express", code: "TE5520193847" },
  { carrier: "Azul Cargo", code: "AZ702938415" },
];

/** One demo code per delivery status (verified against buildShipment). */
export const STATUS_SAMPLES: { status: StepKey; code: string }[] = [
  { status: "separado", code: "QB482000039BR" },
  { status: "postado", code: "QB482000052BR" },
  { status: "transito", code: "QB482000065BR" },
  { status: "centro", code: "QB482000000BR" },
  { status: "saiu", code: "QB482000026BR" },
  { status: "entregue", code: "QB482000117BR" },
];
