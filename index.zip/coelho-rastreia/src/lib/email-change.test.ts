import { expect, test } from "vitest";
import { emailChangeState } from "./email-change";

test("a pending replacement email must not be displayed as completed", () => {
  expect(emailChangeState("ywraul@gmail.com", 0)).toBe("pending");
});

test("one confirmation still leaves the email change pending", () => {
  expect(emailChangeState("ywraul@gmail.com", 1)).toBe("partial");
});

test("no pending email means there is no outstanding change", () => {
  expect(emailChangeState(null, 0)).toBe("complete");
});