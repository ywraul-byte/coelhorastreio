import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import {
  Search, Package, PackageOpen, Truck, Warehouse, Bike, CheckCircle2, MapPin, Clock, History, X, ArrowRight, Radar, ShieldCheck, Zap, Plane,
} from "lucide-react";
import {
  fetchShipment, detectCarrier, CARRIERS, STATUS_SAMPLES, STEP_LABEL, STEP_ORDER, type Shipment, type StepKey,
} from "@/lib/tracking";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Coelho Rastreia — Rastreie sua encomenda em segundos" },
      { name: "description", content: "Rastreie pedidos dos Correios, Jadlog, Loggi, Total Express e Azul Cargo em um só lugar, com timeline detalhada." },
      { property: "og:title", content: "Coelho Rastreia — Rastreamento de encomendas" },
      { property: "og:description", content: "Um código, todas as transportadoras. Acompanhe cada etapa da sua entrega." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const ICONS: Record<StepKey, typeof Package> = { separado: PackageOpen, postado: Package, transito: Truck, centro: Warehouse, saiu: Bike, entregue: CheckCircle2 };
const BADGE: Record<StepKey, string> = {
  separado: "bg-muted text-muted-foreground",
  postado: "bg-muted text-foreground",
  transito: "bg-info/15 text-info",
  centro: "bg-accent text-primary",
  saiu: "bg-primary text-primary-foreground",
  entregue: "bg-success/15 text-success",
};
const fmt = (iso: string) => new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
const fmtDay = (iso: string) => new Date(iso).toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long" });
const KEY = "coelho-rastreia:recentes-v2";
type Recent = { code: string; carrier: string; status: StepKey };

function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="relative grid size-10 place-items-center rounded-sm bg-primary">
        <svg viewBox="0 0 32 32" className="size-7 text-primary-foreground" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
          <path d="M11 14 C9 8 9 3 11 2 C13 3 13.5 8 13 13" />
          <path d="M17 13 C17 8 18 3 20 2.5 C22 4 21 9 19 14" />
          <circle cx="15.5" cy="20" r="6.5" />
          <circle cx="15.5" cy="20" r="2" fill="currentColor" />
          <path d="M24 26 A11 11 0 0 0 26 18" opacity=".7" />
        </svg>
      </div>
      <div className="leading-none">
        <div className="font-display text-lg font-black tracking-tight">COELHO<span className="text-primary">.</span></div>
        <div className="font-mono text-[10px] uppercase tracking-[0.3em] opacity-70">Rastreia</div>
      </div>
    </div>
  );
}

function Index() {
  const [query, setQuery] = useState("");
  const [error, setError] = useState("");
  const [current, setCurrent] = useState<Shipment | null>(null);
  const [recent, setRecent] = useState<Recent[]>([]);
  const [live, setLive] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    try { setRecent(JSON.parse(localStorage.getItem(KEY) || "[]")); } catch { /* ignore */ }
    const c = new URLSearchParams(window.location.search).get("codigo");
    if (c) void track(c);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const saveRecent = (list: Recent[]) => { setRecent(list); localStorage.setItem(KEY, JSON.stringify(list)); };

  const track = async (code: string) => {
    setLoading(true);
    const r = await fetchShipment(code);
    setLoading(false);
    if (!r) { setError("Código não encontrado. Confira o código ou teste um dos exemplos."); return; }
    const s = r.shipment;
    setError(""); setQuery(s.code); setCurrent(s); setLive(r.live);
    setRecent((prev) => {
      const list = [{ code: s.code, carrier: s.carrier, status: s.status }, ...prev.filter((c) => c.code !== s.code)].slice(0, 8);
      localStorage.setItem(KEY, JSON.stringify(list));
      return list;
    });
    setTimeout(() => document.getElementById("resultado")?.scrollIntoView({ behavior: "smooth" }), 50);
  };

  // Live refresh: re-check registered shipments every 15s while open
  useEffect(() => {
    if (!current || !live) return;
    const id = setInterval(async () => {
      const r = await fetchShipment(current.code);
      if (r?.live) setCurrent(r.shipment);
    }, 15000);
    return () => clearInterval(id);
  }, [current?.code, live]);

  const onSubmit = (e: FormEvent) => { e.preventDefault(); track(query); };
  const detected = query.length > 5 ? detectCarrier(query) : null;

  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      {/* HEADER */}
      <header className="sticky top-0 z-30 border-b border-secondary-foreground/10 bg-secondary text-secondary-foreground">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3">
          <Logo />
          <nav className="hidden items-center gap-8 text-sm font-semibold md:flex">
            <a href="#rastrear" className="hover:text-primary">Rastrear</a>
            <a href="#recentes" className="hover:text-primary">Recentes</a>
            <a href="#transportadoras" className="hover:text-primary">Transportadoras</a>
            <a href="/painel" className="hover:text-primary">Área da equipe</a>
          </nav>
          <a href="#rastrear" className="rounded-sm bg-primary px-4 py-2 text-sm font-bold text-primary-foreground hover:bg-primary/90">Rastrear agora</a>
        </div>
      </header>

      {/* HERO */}
      <section id="rastrear" className="relative overflow-hidden bg-secondary text-secondary-foreground">
        <div className="grid-lines absolute inset-0" />
        <div className="pointer-events-none absolute -right-40 top-1/2 size-[640px] -translate-y-1/2 rounded-full border border-primary/30">
          <div className="absolute inset-16 rounded-full border border-primary/20" />
          <div className="absolute inset-36 rounded-full border border-primary/15" />
          <div className="absolute inset-0 animate-spin rounded-full [animation-duration:6s] [background:conic-gradient(from_0deg,transparent_80%,color-mix(in_oklab,var(--primary)_35%,transparent))]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6 py-20 md:py-28">
          <p className="mb-6 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-[0.25em] text-primary">
            <span className="size-2 animate-pulse rounded-full bg-primary" /> Radar de entregas · ao vivo
          </p>
          <h1 className="max-w-4xl font-display text-5xl font-black leading-[0.95] tracking-tight md:text-7xl">
            Rastreio preciso,<br />do envio à <span className="text-primary">sua porta.</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg opacity-75">Cole o código. A gente reconhece a transportadora e mostra cada salto do seu pedido até a sua porta.</p>

          <form onSubmit={onSubmit} className="mt-10 max-w-3xl">
            <div className="flex flex-col gap-2 rounded-sm bg-card p-2 shadow-2xl sm:flex-row">
              <div className="flex flex-1 items-center gap-3 px-3">
                <Search className="size-5 text-muted-foreground" />
                <input
                  value={query}
                  onChange={(e) => { setQuery(e.target.value.toUpperCase()); setError(""); }}
                  placeholder="Ex.: QB482915736BR"
                  aria-label="Código de rastreio"
                  className="w-full bg-transparent py-3 font-mono text-lg text-card-foreground outline-none placeholder:text-muted-foreground"
                />
                {detected && <span className="whitespace-nowrap rounded-sm bg-accent px-2 py-1 font-mono text-xs font-semibold text-primary">{detected}</span>}
              </div>
              <button className="flex items-center justify-center gap-2 rounded-sm bg-primary px-8 py-4 font-bold uppercase tracking-wide text-primary-foreground transition hover:bg-primary/90">
                {loading ? "Buscando…" : "Rastrear"} <ArrowRight className="size-5" />
              </button>
            </div>
            {error && <p className="mt-3 text-sm font-semibold text-primary">{error}</p>}
          </form>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="mr-1 font-mono text-xs uppercase tracking-widest opacity-60">Por status:</span>
            {STATUS_SAMPLES.map((s) => {
              const Icon = ICONS[s.status];
              return (
                <button key={s.code} onClick={() => track(s.code)} className="flex items-center gap-1.5 rounded-sm bg-secondary-foreground/10 px-3 py-1.5 text-xs font-semibold transition hover:bg-primary hover:text-primary-foreground">
                  <Icon className="size-3.5" /> {STEP_LABEL[s.status]}
                </button>
              );
            })}
          </div>
        </div>
        <div className="hazard h-2" />
      </section>

      {/* RESULT */}
      {current && <Result s={current} live={live} onClose={() => setCurrent(null)} />}

      {/* RECENT */}
      <section id="recentes" className="mx-auto max-w-7xl px-6 py-16">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary">Histórico local</p>
            <h2 className="font-display text-3xl font-black tracking-tight">Encomendas recentes</h2>
          </div>
          {recent.length > 0 && <button onClick={() => saveRecent([])} className="text-sm font-semibold text-muted-foreground hover:text-primary">Limpar tudo</button>}
        </div>
        {recent.length === 0 ? (
          <div className="flex items-center gap-4 rounded-sm border border-dashed p-8 text-muted-foreground">
            <History className="size-6" /> Nenhuma encomenda ainda. Os códigos rastreados ficam salvos só neste navegador.
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {recent.map((s) => {
              const code = s.code;
              const Icon = ICONS[s.status] ?? Package;
              return (
                <div key={code} className="group relative rounded-sm border bg-card p-4 transition hover:border-primary">
                  <button onClick={() => track(code)} className="w-full text-left">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase text-muted-foreground">{s.carrier}</span>
                      <Icon className="size-4 text-primary" />
                    </div>
                    <div className="mt-2 font-mono font-semibold">{code}</div>
                    <span className={`mt-3 inline-block rounded-sm px-2 py-0.5 text-xs font-bold ${BADGE[s.status]}`}>{STEP_LABEL[s.status]}</span>
                  </button>
                  <button aria-label="Remover" onClick={() => saveRecent(recent.filter((c) => c.code !== code))} className="absolute bottom-3 right-3 opacity-0 transition group-hover:opacity-100">
                    <X className="size-4 text-muted-foreground hover:text-primary" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* STATS */}
      <section className="bg-secondary text-secondary-foreground">
        <div className="mx-auto grid max-w-7xl grid-cols-2 divide-secondary-foreground/10 px-6 md:grid-cols-3 md:divide-x">
          {[["2,4 mi", "pedidos rastreados"], ["< 1s", "tempo de consulta"], ["98,7%", "códigos reconhecidos"]].map(([n, l]) => (
            <div key={l} className="px-6 py-10">
              <div className="font-display text-4xl font-black text-primary md:text-5xl">{n}</div>
              <div className="mt-1 font-mono text-xs uppercase tracking-widest opacity-70">{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CARRIERS */}
      <section id="transportadoras" className="mx-auto max-w-7xl px-6 py-20">
        <div className="grid gap-12 lg:grid-cols-[1fr_2fr]">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary">Cobertura</p>
            <h2 className="mt-2 font-display text-4xl font-black leading-tight tracking-tight">Um código. Todas as transportadoras.</h2>
            <p className="mt-4 text-muted-foreground">Nosso detector lê o formato do código e encontra a transportadora automaticamente — sem escolher nada em menus.</p>
            <ul className="mt-6 space-y-3 text-sm font-semibold">
              <li className="flex items-center gap-2"><Zap className="size-4 text-primary" /> Reconhecimento automático</li>
              <li className="flex items-center gap-2"><ShieldCheck className="size-4 text-primary" /> Sem cadastro, histórico só no seu navegador</li>
              <li className="flex items-center gap-2"><Radar className="size-4 text-primary" /> Linha do tempo com cada etapa</li>
            </ul>
          </div>
          <div className="grid gap-px overflow-hidden rounded-sm border bg-border sm:grid-cols-2">
            {CARRIERS.map((c, i) => {
              const Icon = c.name === "Azul Cargo" ? Plane : c.name === "Loggi" ? Bike : Truck;
              return (
                <div key={c.name} className="bg-card p-6">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs text-muted-foreground">0{i + 1}</span>
                    <Icon className="size-5 text-primary" />
                  </div>
                  <h3 className="mt-4 font-display text-xl font-extrabold">{c.name}</h3>
                  <p className="text-sm text-muted-foreground">{c.desc}</p>
                  <p className="mt-3 inline-block rounded-sm bg-muted px-2 py-1 font-mono text-xs">{c.pattern}</p>
                </div>
              );
            })}
            <div className="flex flex-col justify-center bg-primary p-6 text-primary-foreground">
              <h3 className="font-display text-xl font-extrabold">Mais em breve</h3>
              <p className="text-sm opacity-90">Mercado Envios, Sequoia e Braspress no próximo salto.</p>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-secondary text-secondary-foreground">
        <div className="hazard h-1.5" />
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-8 sm:flex-row">
          <Logo />
          <p className="font-mono text-xs opacity-60">© 2026 Coelho Rastreia · Dados de demonstração</p>
        </div>
      </footer>
    </div>
  );
}

function Result({ s, live, onClose }: { s: Shipment; live: boolean; onClose: () => void }) {
  const [open, setOpen] = useState(0);
  useEffect(() => setOpen(0), [s.code]);
  const idx = STEP_ORDER.indexOf(s.status);
  return (
    <section id="resultado" className="mx-auto max-w-7xl scroll-mt-20 px-6 pt-16">
      <div className="overflow-hidden rounded-sm border bg-card shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b p-6">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{s.carrier} · código {live ? <span className="ml-2 text-success">● ao vivo</span> : <span className="ml-2">· demonstração</span>}</p>
            <h2 className="font-mono text-2xl font-bold md:text-3xl">{s.code}</h2>
          </div>
          <div className="flex items-center gap-3">
            <span className={`rounded-sm px-3 py-1.5 text-sm font-bold uppercase tracking-wide ${BADGE[s.status]}`}>{STEP_LABEL[s.status]}</span>
            <button aria-label="Fechar" onClick={onClose} className="rounded-sm p-2 hover:bg-muted"><X className="size-4" /></button>
          </div>
        </div>
        <div className="grid divide-y sm:grid-cols-3 sm:divide-x sm:divide-y-0">
          {[["Origem", s.origin, MapPin], ["Destino", s.destination, MapPin], [s.status === "entregue" ? "Entregue em" : "Previsão", s.status === "entregue" && s.events[0] ? fmtDay(s.events[0].date) : s.eta ? fmtDay(s.eta) : "A definir", Clock]].map(([l, v, I]) => {
            const Ico = I as typeof MapPin;
            return (
              <div key={l as string} className="flex items-start gap-3 p-6">
                <Ico className="mt-0.5 size-5 text-primary" />
                <div><p className="text-xs font-bold uppercase text-muted-foreground">{l as string}</p><p className="font-semibold capitalize">{v as string}</p></div>
              </div>
            );
          })}
        </div>
        {/* progress */}
        <div className="border-t bg-muted/50 px-6 py-8">
          <div className="relative flex justify-between">
            <div className="absolute left-5 right-5 top-5 h-1 bg-border" />
            <div className="absolute left-5 top-5 h-1 bg-primary transition-all duration-700" style={{ width: `calc((100% - 2.5rem) * ${idx / (STEP_ORDER.length - 1)})` }} />
            {STEP_ORDER.map((k, i) => {
              const Icon = ICONS[k];
              const done = i <= idx;
              return (
                <div key={k} className="relative flex w-20 flex-col items-center text-center">
                  <div className={`grid size-10 place-items-center rounded-full border-2 ${done ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-muted-foreground"} ${i === idx && k !== "entregue" ? "ring-4 ring-primary/25" : ""}`}>
                    <Icon className="size-4" />
                  </div>
                  <span className={`mt-2 text-[11px] font-bold leading-tight ${done ? "" : "text-muted-foreground"}`}>{STEP_LABEL[k]}</span>
                </div>
              );
            })}
          </div>
        </div>
        {/* timeline */}
        <div className="border-t p-6">
          <h3 className="mb-6 font-display text-lg font-extrabold">Linha do tempo</h3>
          {s.events.length === 0 && <p className="text-sm text-muted-foreground">Ainda sem movimentações.</p>}
          <ol className="relative ml-5 border-l-2 border-border">
            {s.events.map((e, i) => {
              const Icon = ICONS[e.step];
              const active = open === i;
              return (
                <li key={e.step} className="mb-6 ml-8 last:mb-0">
                  <span className={`absolute -left-[21px] grid size-10 place-items-center rounded-full border-4 border-card ${i === 0 ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}>
                    <Icon className="size-4" />
                  </span>
                  <button onClick={() => setOpen(active ? -1 : i)} className={`w-full rounded-sm border p-4 text-left transition ${active ? "border-primary bg-accent/40" : "hover:border-primary/50"}`}>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-bold">{e.title}</span>
                      <span className="font-mono text-xs text-muted-foreground">{fmt(e.date)}</span>
                    </div>
                    <p className="mt-1 flex items-center gap-1 text-sm text-muted-foreground"><MapPin className="size-3.5" /> {e.location}</p>
                    {active && <p className="mt-3 border-t pt-3 text-sm">{e.detail}</p>}
                  </button>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </section>
  );
}
