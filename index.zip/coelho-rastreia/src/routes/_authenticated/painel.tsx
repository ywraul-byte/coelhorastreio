import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, type FormEvent } from "react";
import { ArrowLeft, LogOut, Package, CheckCircle2, Truck, PackageOpen, Plus, Trash2, ExternalLink, Search, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { CARRIERS, STEP_LABEL, STEP_ORDER, type StepKey } from "@/lib/tracking";
import type { Tables } from "@/integrations/supabase/types";
import { filterShipments, type ShipmentStatusFilter } from "@/lib/shipment-filters";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { TeamManagement } from "@/components/team-management";
import { EmailChangeStatus } from "@/components/email-change-status";
import { canManageTeam } from "@/lib/team-permissions";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({
    meta: [
      { title: "Painel — Coelho Rastreia" },
      { name: "description", content: "Cadastro e gestão de encomendas do Coelho Rastreia." },
      { property: "og:title", content: "Painel — Coelho Rastreia" },
      { property: "og:description", content: "Gestão de encomendas e status de entrega." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Painel,
});

type ShipmentRow = Tables<"shipments">;
type EventRow = Tables<"shipment_events">;

export const DEFAULT_TITLE: Record<StepKey, string> = {
  separado: "Seu pedido está sendo preparado para envio",
  postado: "Objeto postado",
  transito: "Em trânsito",
  centro: "No centro de distribuição",
  saiu: "Saiu para entrega",
  entregue: "Entregue ao destinatário",
};

const input = "w-full rounded-sm border bg-background px-3 py-2 text-sm outline-none focus:border-primary";
const label = "mb-1 block text-xs font-bold uppercase text-muted-foreground";

function Painel() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [selected, setSelected] = useState<string | null>(null);
  const [codeSearch, setCodeSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<ShipmentStatusFilter>("all");

  const roleQ = useQuery({
    queryKey: ["my-role", user.id],
    queryFn: async () => (await supabase.from("user_roles").select("role").eq("user_id", user.id)).data ?? [],
  });
  const shipmentsQ = useQuery({
    queryKey: ["shipments"],
    enabled: (roleQ.data?.length ?? 0) > 0,
    queryFn: async () => {
      const { data, error } = await supabase.from("shipments").select("*").order("updated_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const signOut = async () => {
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  const header = (
    <header className="bg-secondary text-secondary-foreground">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-6 py-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary">Área da equipe</p>
          <h1 className="font-display text-2xl font-black">Painel Coelho Rastreia</h1>
        </div>
        <div className="flex items-center gap-5 text-sm font-semibold">
          <span className="hidden opacity-70 sm:inline">{user.email}</span>
          <Link to="/" className="flex items-center gap-1.5 hover:text-primary"><ArrowLeft className="size-4" /> Site</Link>
          <button onClick={signOut} className="flex items-center gap-1.5 hover:text-primary"><LogOut className="size-4" /> Sair</button>
        </div>
      </div>
      <div className="hazard h-1.5" />
    </header>
  );

  if (roleQ.isLoading) return <div className="min-h-screen bg-background">{header}</div>;
  if (!roleQ.data?.length) {
    return (
      <div className="min-h-screen bg-background">{header}
        <div className="mx-auto max-w-xl px-6 py-20 text-center">
          <h2 className="font-display text-2xl font-black">Acesso pendente</h2>
          <p className="mt-2 text-muted-foreground">Sua conta ainda não foi liberada pelo dono. Peça para ele adicionar você à equipe.</p>
        </div>
      </div>
    );
  }

  const list = shipmentsQ.data ?? [];
  const filteredList = filterShipments(list, codeSearch, statusFilter);
  const hasFilters = codeSearch.length > 0 || statusFilter !== "all";
  const clearFilters = () => { setCodeSearch(""); setStatusFilter("all"); };
  const count = (k: StepKey) => list.filter((s) => s.status === k).length;
  const kpis = [
    { l: "Encomendas", v: list.length, I: Package },
    { l: "Em preparação", v: count("separado"), I: PackageOpen },
    { l: "Saindo para entrega", v: count("saiu"), I: Truck },
    { l: "Entregues", v: count("entregue"), I: CheckCircle2 },
  ];
  const current = list.find((s) => s.id === selected) ?? null;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {header}
      <main className="mx-auto max-w-7xl space-y-8 px-6 py-10">
        <EmailChangeStatus userId={user.id} />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {kpis.map(({ l, v, I }) => (
            <div key={l} className="rounded-sm border bg-card p-5">
              <div className="flex items-center justify-between text-muted-foreground"><span className="text-xs font-bold uppercase">{l}</span><I className="size-4 text-primary" /></div>
              <div className="mt-3 font-display text-4xl font-black">{v}</div>
            </div>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
          <NewShipment onCreated={(id) => { qc.invalidateQueries({ queryKey: ["shipments"] }); setSelected(id); }} />

          <div className="rounded-sm border bg-card">
            <div className="space-y-4 border-b p-5">
              <h2 className="font-display text-lg font-extrabold">Encomendas cadastradas</h2>
              <div className="flex flex-col gap-3 sm:flex-row">
                <div className="relative min-w-0 flex-1">
                  <Search aria-hidden="true" className="pointer-events-none absolute left-3 top-2.5 size-4 text-muted-foreground" />
                  <Input type="search" aria-label="Buscar por código" placeholder="Buscar por código" value={codeSearch} onChange={(e) => setCodeSearch(e.target.value)} className="pl-9 font-mono" />
                </div>
                <Select value={statusFilter} onValueChange={(value) => { if (value === "all" || STEP_ORDER.includes(value as StepKey)) setStatusFilter(value as ShipmentStatusFilter); }}>
                  <SelectTrigger aria-label="Filtrar por status" className="w-full sm:w-52"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os status</SelectItem>
                    {STEP_ORDER.map((status) => <SelectItem key={status} value={status}>{STEP_LABEL[status]}</SelectItem>)}
                  </SelectContent>
                </Select>
                {hasFilters && <Button type="button" variant="ghost" size="icon" aria-label="Limpar filtros" title="Limpar filtros" onClick={clearFilters}><X /></Button>}
              </div>
              <p role="status" className="text-xs text-muted-foreground">{filteredList.length} de {list.length} encomendas</p>
            </div>
            {shipmentsQ.isLoading ? (
              <p className="p-6 text-sm text-muted-foreground">Carregando encomendas…</p>
            ) : shipmentsQ.isError ? (
              <p className="p-6 text-sm text-destructive">Não foi possível carregar as encomendas.</p>
            ) : list.length === 0 ? (
              <p className="p-6 text-sm text-muted-foreground">Nenhuma encomenda ainda. Cadastre a primeira ao lado.</p>
            ) : filteredList.length === 0 ? (
              <div className="space-y-3 p-6 text-center">
                <p className="text-sm text-muted-foreground">Nenhuma encomenda encontrada para esta busca e status.</p>
                <Button type="button" variant="outline" onClick={clearFilters}><X /> Limpar filtros</Button>
              </div>
            ) : (
              <div className="max-h-[520px] overflow-auto">
                <table className="w-full text-sm">
                  <thead className="sticky top-0 bg-card"><tr className="text-left text-xs uppercase text-muted-foreground"><th className="px-5 py-2">Código</th><th className="py-2">Destinatário</th><th className="hidden py-2 md:table-cell">Destino</th><th className="py-2 pr-5">Status</th></tr></thead>
                  <tbody>
                    {filteredList.map((s) => (
                      <tr key={s.id} onClick={() => setSelected(s.id)} className={`cursor-pointer border-t hover:bg-muted/60 ${selected === s.id ? "bg-accent/50" : ""}`}>
                        <td className="px-5 py-3 font-mono font-semibold">{s.code}<div className="font-sans text-xs font-normal text-muted-foreground">{s.carrier}</div></td>
                        <td className="py-3">{s.recipient}{s.product && <div className="text-xs text-muted-foreground">{s.product}</div>}</td>
                        <td className="hidden py-3 md:table-cell">{s.destination}</td>
                        <td className="py-3 pr-5"><span className="rounded-sm bg-accent px-2 py-0.5 text-xs font-bold text-primary">{STEP_LABEL[s.status]}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {current && <Manage key={current.id} s={current} onChanged={() => qc.invalidateQueries({ queryKey: ["shipments"] })} onDeleted={() => { setSelected(null); qc.invalidateQueries({ queryKey: ["shipments"] }); }} />}
        {canManageTeam(roleQ.data.map((row) => row.role)) && <TeamManagement ownerId={user.id} />}
      </main>
    </div>
  );
}

export function NewShipment({ onCreated }: { onCreated: (id: string) => void }) {
  const [f, setF] = useState({ recipient: "", product: "", origin: "", destination: "", carrier: "Correios", eta: "" });
  const [initialStep, setInitialStep] = useState<StepKey>("separado");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true); setMsg("");
    try {
      const { data, error } = await supabase.rpc("create_team_order", {
        _recipient: f.recipient.trim(), _product: f.product.trim(), _origin: f.origin.trim(),
        _destination: f.destination.trim(), _carrier: f.carrier, _eta: f.eta, _step: initialStep,
      });
      const created = data?.[0];
      if (error || !created) { setMsg("Não foi possível criar o pedido. Confira os campos e tente novamente."); return; }
      setMsg(`Pedido criado · ${created.code}`);
      setF({ recipient: "", product: "", origin: "", destination: "", carrier: f.carrier, eta: "" });
      setInitialStep("separado");
      onCreated(created.id);
    } catch {
      setMsg("Não foi possível criar o pedido. Tente novamente.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} aria-label="Novo pedido" className="space-y-4 rounded-sm border bg-card p-5">
      <h2 className="flex items-center gap-2 font-display text-xl font-extrabold"><Plus className="size-5 text-primary" /> Novo pedido</h2>
      <div><label htmlFor="order-client" className={label}>Cliente</label><Input id="order-client" required maxLength={120} value={f.recipient} onChange={set("recipient")} placeholder="Maria Souza" /></div>
      <div><label htmlFor="order-product" className={label}>Pedido ou produto</label><Input id="order-product" required maxLength={240} value={f.product} onChange={set("product")} placeholder="Kit com 3 camisetas" /></div>
      <div><label htmlFor="order-eta" className={label}>Previsão de entrega</label><Input id="order-eta" type="date" required value={f.eta} onChange={set("eta")} className="min-w-0" /></div>
      <div><label id="initial-step-label" className={label}>Etapa inicial</label>
        <Select value={initialStep} onValueChange={(value) => { if (STEP_ORDER.includes(value as StepKey)) setInitialStep(value as StepKey); }}>
          <SelectTrigger aria-labelledby="initial-step-label" className="w-full"><SelectValue /></SelectTrigger>
          <SelectContent>{STEP_ORDER.map((k) => <SelectItem key={k} value={k}>{k === "separado" ? "Preparando para envio" : STEP_LABEL[k]}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="min-w-0"><label htmlFor="order-origin" className={label}>Origem</label><Input id="order-origin" maxLength={80} value={f.origin} onChange={set("origin")} placeholder="São Paulo, SP" /></div>
        <div className="min-w-0"><label htmlFor="order-destination" className={label}>Cidade de destino</label><Input id="order-destination" required maxLength={80} value={f.destination} onChange={set("destination")} /></div>
      </div>
      <div><label id="order-carrier-label" className={label}>Transportadora</label>
        <Select value={f.carrier} onValueChange={(carrier) => setF({ ...f, carrier })}>
          <SelectTrigger aria-labelledby="order-carrier-label" className="w-full"><SelectValue /></SelectTrigger>
          <SelectContent>{CARRIERS.map((c) => <SelectItem key={c.name} value={c.name}>{c.name}</SelectItem>)}<SelectItem value="Outra">Outra</SelectItem></SelectContent>
        </Select>
      </div>
      {msg && <p role="status" className="break-all text-sm font-semibold">{msg}</p>}
      <Button disabled={busy} type="submit" className="w-full font-bold" size="lg"><Plus />{busy ? "Criando…" : "Criar pedido"}</Button>
    </form>
  );
}

function Manage({ s, onChanged, onDeleted }: { s: ShipmentRow; onChanged: () => void; onDeleted: () => void }) {
  const qc = useQueryClient();
  const eventsQ = useQuery({
    queryKey: ["events", s.id],
    queryFn: async () => (await supabase.from("shipment_events").select("*").eq("shipment_id", s.id).order("occurred_at", { ascending: false })).data ?? [],
  });
  const [step, setStep] = useState<StepKey>(STEP_ORDER[Math.min(STEP_ORDER.indexOf(s.status) + 1, 5)] ?? "entregue");
  const [title, setTitle] = useState(DEFAULT_TITLE[step]);
  const [detail, setDetail] = useState("");
  const [location, setLocation] = useState(s.destination);
  const [busy, setBusy] = useState(false);

  const addEvent = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    await supabase.from("shipment_events").insert({ shipment_id: s.id, step, title: title.trim() || DEFAULT_TITLE[step], detail: detail.trim(), location: location.trim() });
    await supabase.from("shipments").update({ status: step, updated_at: new Date().toISOString() }).eq("id", s.id);
    setBusy(false); setDetail("");
    qc.invalidateQueries({ queryKey: ["events", s.id] });
    onChanged();
  };
  const removeEvent = async (ev: EventRow) => {
    await supabase.from("shipment_events").delete().eq("id", ev.id);
    qc.invalidateQueries({ queryKey: ["events", s.id] });
  };
  const removeShipment = async () => {
    if (!confirm(`Excluir a encomenda ${s.code}?`)) return;
    await supabase.from("shipments").delete().eq("id", s.id);
    onDeleted();
  };

  return (
    <section className="rounded-sm border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b p-5">
        <div>
          <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">{s.carrier} · {s.recipient} · {s.origin || "—"} → {s.destination}</p>
          <h2 className="font-mono text-2xl font-bold">{s.code}</h2>
          {s.product && <p className="mt-1 text-sm text-muted-foreground">{s.product}</p>}
        </div>
        <div className="flex items-center gap-4 text-sm font-semibold">
          <span className="rounded-sm bg-accent px-3 py-1 text-xs font-bold uppercase text-primary">{STEP_LABEL[s.status]}</span>
          <a href={`/?codigo=${s.code}`} target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-primary"><ExternalLink className="size-4" /> Ver como cliente</a>
          <button onClick={removeShipment} className="flex items-center gap-1 text-destructive"><Trash2 className="size-4" /> Excluir</button>
        </div>
      </div>
      <div className="grid gap-6 p-5 lg:grid-cols-[380px_1fr]">
        <form onSubmit={addEvent} className="space-y-3">
          <h3 className="font-display font-extrabold">Atualizar status / novo evento</h3>
          <div><label className={label}>Etapa</label>
            <select value={step} onChange={(e) => { const k = e.target.value as StepKey; setStep(k); setTitle(DEFAULT_TITLE[k]); }} className={input}>
              {STEP_ORDER.map((k) => <option key={k} value={k}>{STEP_LABEL[k]}</option>)}
            </select>
          </div>
          <div><label className={label}>Mensagem para o cliente</label><input maxLength={140} value={title} onChange={(e) => setTitle(e.target.value)} className={input} /></div>
          <div><label className={label}>Detalhe (opcional)</label><input maxLength={240} value={detail} onChange={(e) => setDetail(e.target.value)} className={input} /></div>
          <div><label className={label}>Local</label><input maxLength={80} value={location} onChange={(e) => setLocation(e.target.value)} className={input} /></div>
          <button disabled={busy} className="w-full rounded-sm bg-primary py-2.5 font-bold uppercase tracking-wide text-primary-foreground hover:bg-primary/90 disabled:opacity-60">{busy ? "Salvando…" : "Adicionar à timeline"}</button>
        </form>
        <div>
          <h3 className="mb-3 font-display font-extrabold">Timeline</h3>
          <ol className="space-y-2">
            {(eventsQ.data ?? []).map((ev) => (
              <li key={ev.id} className="flex items-start justify-between gap-3 rounded-sm border p-3">
                <div>
                  <div className="flex flex-wrap items-center gap-2"><span className="rounded-sm bg-muted px-1.5 py-0.5 text-[10px] font-bold uppercase">{STEP_LABEL[ev.step]}</span><span className="font-semibold">{ev.title}</span></div>
                  <p className="mt-1 text-xs text-muted-foreground">{ev.location} · {new Date(ev.occurred_at).toLocaleString("pt-BR")}{ev.detail ? ` · ${ev.detail}` : ""}</p>
                </div>
                <button aria-label="Remover evento" onClick={() => removeEvent(ev)} className="text-muted-foreground hover:text-destructive"><Trash2 className="size-4" /></button>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
