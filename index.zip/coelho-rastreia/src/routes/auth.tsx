import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { ArrowLeft, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — Área da equipe Coelho Rastreia" },
      { name: "description", content: "Acesso restrito ao dono e à equipe do Coelho Rastreia." },
      { property: "og:title", content: "Área da equipe — Coelho Rastreia" },
      { property: "og:description", content: "Acesso restrito ao painel de gestão de encomendas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true); setMsg("");
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      setBusy(false);
      if (error) return setMsg("E-mail ou senha incorretos.");
      navigate({ to: "/painel" });
    } else {
      if (password.length < 8) { setBusy(false); return setMsg("A senha precisa ter pelo menos 8 caracteres."); }
      const { error } = await supabase.auth.signUp({ email: email.trim(), password, options: { emailRedirectTo: `${window.location.origin}/painel` } });
      setBusy(false);
      if (error) return setMsg(error.message);
      setMsg("Conta criada! Confirme pelo link enviado ao seu e-mail e depois entre.");
      setMode("in");
    }
  };

  return (
    <div className="grid min-h-screen place-items-center bg-secondary px-4 text-secondary-foreground">
      <div className="grid-lines pointer-events-none fixed inset-0" />
      <div className="relative w-full max-w-md">
        <Link to="/" className="mb-6 inline-flex items-center gap-2 text-sm font-semibold opacity-80 hover:text-primary"><ArrowLeft className="size-4" /> Voltar ao rastreio</Link>
        <form onSubmit={submit} className="rounded-sm bg-card p-8 text-card-foreground shadow-2xl">
          <div className="mb-6 flex items-center gap-3">
            <div className="grid size-10 place-items-center rounded-sm bg-primary text-primary-foreground"><Lock className="size-5" /></div>
            <div>
              <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary">Área da equipe</p>
              <h1 className="font-display text-2xl font-black">{mode === "in" ? "Entrar no painel" : "Criar conta"}</h1>
            </div>
          </div>
          <label className="mb-1 block text-xs font-bold uppercase text-muted-foreground">E-mail</label>
          <input type="email" required maxLength={255} value={email} onChange={(e) => setEmail(e.target.value)} className="mb-4 w-full rounded-sm border bg-background px-3 py-2.5 outline-none focus:border-primary" />
          <label className="mb-1 block text-xs font-bold uppercase text-muted-foreground">Senha</label>
          <input type="password" required maxLength={72} value={password} onChange={(e) => setPassword(e.target.value)} className="mb-5 w-full rounded-sm border bg-background px-3 py-2.5 outline-none focus:border-primary" />
          {msg && <p className="mb-4 text-sm font-semibold text-primary">{msg}</p>}
          <button disabled={busy} className="w-full rounded-sm bg-primary py-3 font-bold uppercase tracking-wide text-primary-foreground hover:bg-primary/90 disabled:opacity-60">
            {busy ? "Aguarde…" : mode === "in" ? "Entrar" : "Criar conta"}
          </button>
          <button type="button" onClick={() => { setMode(mode === "in" ? "up" : "in"); setMsg(""); }} className="mt-4 w-full text-sm text-muted-foreground hover:text-primary">
            {mode === "in" ? "Primeiro acesso? Criar conta" : "Já tenho conta"}
          </button>
        </form>
      </div>
    </div>
  );
}
