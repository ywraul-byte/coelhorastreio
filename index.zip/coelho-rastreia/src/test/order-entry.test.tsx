import { fireEvent, render, screen, waitFor, cleanup } from "@testing-library/react";
import { afterEach, expect, test, vi } from "vitest";

const { rpc } = vi.hoisted(() => ({ rpc: vi.fn() }));
vi.mock("@/integrations/supabase/client", () => ({ supabase: { rpc } }));
import { NewShipment } from "@/routes/_authenticated/painel";
afterEach(cleanup);

test("new orders send the product and preparation stage without a manually supplied code", async () => {
  rpc.mockResolvedValue({ data: [{ id: "order-1", code: "CR123456" }], error: null });
  const created = vi.fn();
  render(<NewShipment onCreated={created} />);
  fireEvent.change(screen.getByLabelText("Cliente"), { target: { value: "Maria Souza" } });
  fireEvent.change(screen.getByLabelText("Pedido ou produto"), { target: { value: "Kit com 3 camisetas" } });
  fireEvent.change(screen.getByLabelText("Cidade de destino"), { target: { value: "Curitiba, PR" } });
  fireEvent.change(screen.getByLabelText("Previsão de entrega"), { target: { value: "2026-11-12" } });
  fireEvent.submit(screen.getByRole("form", { name: "Novo pedido" }));
  await waitFor(() => expect(created).toHaveBeenCalledWith("order-1"));
  expect(rpc).toHaveBeenCalledWith("create_team_order", {
    _recipient: "Maria Souza", _product: "Kit com 3 camisetas", _destination: "Curitiba, PR",
    _origin: "", _carrier: "Correios", _eta: "2026-11-12", _step: "separado",
  });
});